# Asset Population Scripts for Security Dashboard

This folder contains automation scripts to set up a Windows Active Directory lab environment and scan assets for the Security Dashboard.

## 📁 Files

| File | Description | Run On |
|------|-------------|--------|
| `Server_Setup.ps1` | Sets up Windows Server as Domain Controller | Node 1 (Server) |
| `Client_Join.ps1` | Joins client to domain, enables WinRM | Node 2 (Client) |
| `Asset_Scanner.py` | Scans AD computers for security compliance | Node 1 (Server) |
| `requirements.txt` | Python dependencies for Asset_Scanner.py | Node 1 (Server) |

## 🏗️ Environment Setup

### Network Configuration
- **Subnet:** `192.168.1.0/24`
- **Gateway:** `192.168.1.1`
- **Domain Controller IP:** `192.168.1.50`
- **Domain:** `meezan.local`

### Credentials
- **Domain Admin:** `Administrator` (password set during DC promotion)
- **Service Account:** `svc_scanner` / `CyberSec2025!`
- **Safe Mode Password:** `SafeMode2025!`

## 🚀 Deployment Steps

### Step 1: Server Setup (Node 1)

Run on Windows Server 2022:

```powershell
# Open PowerShell as Administrator
Set-ExecutionPolicy Bypass -Scope Process -Force
.\Server_Setup.ps1
```

**What it does:**
1. ✅ Sets static IP to `192.168.1.50`
2. ✅ Sets DNS to `127.0.0.1`
3. ✅ Installs AD Domain Services & GPMC
4. ✅ Promotes server to Domain Controller for `meezan.local`
5. ✅ **Server reboots automatically**
6. ✅ After reboot, creates `svc_scanner` service account
7. ✅ Configures WinRM

**Note:** The script creates a scheduled task to continue setup after reboot. Run the script once and let it complete.

### Step 2: Client Join (Node 2)

After the server is fully configured, run on Windows 10/11 client:

```powershell
# Open PowerShell as Administrator
Set-ExecutionPolicy Bypass -Scope Process -Force
.\Client_Join.ps1
```

**What it does:**
1. ✅ Sets DNS to Domain Controller (`192.168.1.50`)
2. ✅ Enables WinRM service
3. ✅ Adds firewall rule for port 5985
4. ✅ Joins computer to `meezan.local` domain
5. ✅ **Client reboots automatically**

**Credentials prompt:** Enter the Domain Administrator password when prompted.

### Step 3: Run Asset Scanner (Node 1)

After clients are joined to the domain:

```bash
# Install Python dependencies
pip install -r requirements.txt

# Run the scanner
python Asset_Scanner.py
```

**Output format:**
```json
[
  {
    "asset_name": "LAPTOP-CLIENT1",
    "ip_address": "192.168.1.101",
    "compliance_status": "Compliant",
    "details": {
      "antivirus": true,
      "real_time_protection": true,
      "operating_system": "Windows 10 Pro"
    }
  }
]
```

## 📋 Asset Scanner Options

```bash
# Default scan
python Asset_Scanner.py

# Demo mode (no AD required - generates sample data)
python Asset_Scanner.py --demo

# Custom domain
python Asset_Scanner.py --domain corp.local --dc-ip 10.0.0.5

# Save output to file
python Asset_Scanner.py --output results.json

# Include Domain Controller in scan
python Asset_Scanner.py --include-dc

# Verbose output
python Asset_Scanner.py -v

# Quiet mode (JSON only)
python Asset_Scanner.py --quiet
```

## 🔧 Troubleshooting

### Server Setup Issues

**DNS not resolving:**
```powershell
# Verify DNS service
Get-Service DNS
nslookup meezan.local 127.0.0.1
```

**AD DS not promoting:**
```powershell
# Check prerequisites
Get-WindowsFeature AD-Domain-Services
Test-ADDSForestInstallation -DomainName "meezan.local"
```

### Client Join Issues

**Cannot find domain:**
```powershell
# Verify DNS is pointing to DC
Get-DnsClientServerAddress
nslookup meezan.local
ping 192.168.1.50
```

**Access denied:**
- Ensure using correct domain admin credentials
- Format: `meezan.local\Administrator`

### Scanner Issues

**LDAP connection failed:**
```bash
# Test LDAP port
telnet 192.168.1.50 389

# Check firewall on DC
netsh advfirewall firewall show rule name=all | findstr LDAP
```

**WinRM connection failed:**
```powershell
# On target machine, verify WinRM
Get-Service WinRM
winrm enumerate winrm/config/listener

# Test from DC
Test-WSMan -ComputerName "CLIENT-HOSTNAME"
```

**Host unreachable:**
- Check if client is powered on
- Verify firewall allows port 5985
- Ensure client is on same network

## 🔒 Security Notes

1. **Credentials:** The service account password is hardcoded for lab use. Change in production!
2. **WinRM Security:** Scripts enable basic auth and unencrypted traffic for lab simplicity. Use HTTPS in production.
3. **Firewall:** Scripts open necessary ports. Review rules in production.

## 📊 Integration with Security Dashboard

The JSON output from `Asset_Scanner.py` is designed to populate the **Asset Inventory** section of the Security Dashboard. The compliance statuses map to:

| Status | Dashboard Display | Meaning |
|--------|-------------------|---------|
| `Compliant` | ✅ OK | AV enabled + Real-time protection ON |
| `Partial` | ⚠️ Partial | Only one protection enabled |
| `Non-Compliant` | ❌ Non | Both protections disabled |
| `Unknown` | ❓ Unknown | Host unreachable or error |

## 📝 Logs

- **Server Setup:** `%TEMP%\Server_Setup_<timestamp>.log`
- **Client Join:** `%TEMP%\Client_Join_<timestamp>.log`
- **Asset Scanner:** `asset_scanner.log` (same directory)

## 🔄 Re-running Scripts

- **Server_Setup.ps1:** Safe to re-run; detects if DC is already configured
- **Client_Join.ps1:** Safe to re-run; detects if already joined to domain
- **Asset_Scanner.py:** Can run anytime to get fresh scan results
